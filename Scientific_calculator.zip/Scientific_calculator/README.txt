this is my first program!

you need to click project_calculator.sln for see my code and form.

I added a shortcut and its name is Project_Calculator.exe



